
# AI Novel Scraper Docs

This documentation package contains a full blueprint for building a free AI-assisted web novel scraping system.

## Features

- Automatic chapter detection
- AI-based content extraction
- Multi-site support
- Update tracking
- Local database storage

## Recommended Stack

Python
Playwright
BeautifulSoup
SQLite
AutoScraper
Optional: Local LLM (Ollama)

## Project Structure

docs/
architecture.md
development-guide.md
ai-extraction.md
scraping-strategies.md
deployment.md

Use these documents to build the full system step by step.
