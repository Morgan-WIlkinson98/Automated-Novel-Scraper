
# AI Extraction Strategy

The scraper identifies chapter text automatically using content-density heuristics.

Typical chapter characteristics:
- 2000–8000 words
- Many paragraphs
- Low link density

## Extraction Algorithm

1. Find all content blocks (divs)
2. Measure text length
3. Select block with largest text size

Example:

def extract_main_content(soup):
    candidates = []

    for div in soup.find_all("div"):
        text = div.get_text()
        if len(text) > 500:
            candidates.append((len(text), div))

    best = max(candidates, key=lambda x: x[0])
    return best[1].get_text()
