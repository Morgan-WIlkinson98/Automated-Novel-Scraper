
# Deployment Guide

## Local Deployment

Run the main script:

python main.py

The scheduler will run automatically.

## Optional Server Deployment

You can deploy using:

- Docker
- VPS (DigitalOcean, Linode, etc)
- Cron jobs
- systemd services

## Suggested Automation

Run scraper every 30 minutes to check for updates.
