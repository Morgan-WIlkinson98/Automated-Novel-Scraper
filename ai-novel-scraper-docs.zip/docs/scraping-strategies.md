
# Scraping Strategies

## Incremental Scraping
Only fetch chapters that do not exist in the database.

Benefits:
- Faster
- Lower bandwidth
- Less chance of being blocked

## DOM Scoring

Score elements by:
- text length
- paragraph density
- link ratio

Select the highest scoring block as chapter content.

## Pattern Storage

Store successful selectors per website so the scraper improves over time.
