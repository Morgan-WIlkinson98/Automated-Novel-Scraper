
# Architecture Overview

## Goal
Build a free AI-assisted web novel scraper that:
- Detects new chapters
- Extracts chapter content automatically
- Stores chapters locally
- Works across multiple novel sites

## System Pipeline

Scheduler
↓
Crawler
↓
Renderer (Playwright)
↓
HTML Parser
↓
AI Extraction Engine
↓
Content Cleaner
↓
Database
↓
Update Detector
↓
Notifier

## Components

### Scheduler
Runs scraping jobs at intervals.

### Crawler
Fetches page HTML.

### Renderer
Uses Playwright for JavaScript pages.

### Parser
Converts HTML to a structured DOM.

### AI Extraction Engine
Finds title and chapter text automatically.

### Cleaner
Removes ads, menus, and junk content.

### Database
Stores novels and chapters.

### Update Detector
Detects newly published chapters.

### Notifier
Sends alerts (email, Discord, etc).
