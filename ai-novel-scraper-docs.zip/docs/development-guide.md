
# Development Guide

## Step 1 — Environment Setup

Install dependencies:

pip install requests beautifulsoup4 lxml playwright autoscraper schedule sqlalchemy sentence-transformers

Install browsers:

playwright install

## Step 2 — Build Renderer

Purpose: Render JavaScript pages.

Example:

from playwright.sync_api import sync_playwright

def render_page(url):
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.goto(url)
        html = page.content()
        browser.close()
    return html

## Step 3 — Build Crawler

import requests

def fetch_page(url):
    r = requests.get(url)
    if r.status_code == 200:
        return r.text
    return None

## Step 4 — Parse HTML

from bs4 import BeautifulSoup

def parse_html(html):
    return BeautifulSoup(html, "lxml")
