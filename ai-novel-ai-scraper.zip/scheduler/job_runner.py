
import schedule
import time
from config.settings import SCRAPE_INTERVAL_MINUTES
from main import run

def start():

    schedule.every(SCRAPE_INTERVAL_MINUTES).minutes.do(run)

    while True:
        schedule.run_pending()
        time.sleep(1)
