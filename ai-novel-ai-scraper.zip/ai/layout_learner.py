
import json
import os

PATTERN_FILE = "site_patterns.json"

def load_patterns():

    if not os.path.exists(PATTERN_FILE):
        return {}

    with open(PATTERN_FILE) as f:
        return json.load(f)

def save_patterns(patterns):

    with open(PATTERN_FILE,"w") as f:
        json.dump(patterns,f,indent=2)

def learn_selector(site, selector):

    patterns = load_patterns()

    patterns[site] = selector

    save_patterns(patterns)
