
def notify(title):

    print("NEW CHAPTER:", title)
