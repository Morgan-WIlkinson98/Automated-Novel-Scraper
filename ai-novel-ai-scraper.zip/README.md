
# AI Novel Scraper

A local AI-assisted web novel scraping system that:

- Detects new chapters
- Extracts chapter text automatically
- Works across many novel sites
- Stores chapters locally
- Self-learns page structures

## Stack

Python
Playwright
BeautifulSoup
SQLite
Sentence Transformers (optional)
Local LLM via Ollama (optional)

## Run

pip install -r requirements.txt
playwright install

python main.py
