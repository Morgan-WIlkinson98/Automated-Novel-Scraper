
from scraper.crawler import fetch
from scraper.parser import parse
from scraper.extractor import extract_main_text
from scraper.chapter_detector import detect_chapter_links
from scraper.cleaner import clean_text
from scraper.update_detector import chapter_exists
from notifications.notifier import notify
from database.db import init_db, get_conn
from utils.url import get_domain

NOVEL_LIST = [
]

def save_chapter(title,url,content):

    conn = get_conn()
    c = conn.cursor()

    c.execute(
        "INSERT INTO chapters(title,url,content) VALUES(?,?,?)",
        (title,url,content)
    )

    conn.commit()
    conn.close()

def process_chapter(url):

    if chapter_exists(url):
        return

    html = fetch(url)

    soup = parse(html)

    title = soup.title.string if soup.title else "Chapter"

    text = extract_main_text(soup)

    text = clean_text(text)

    if len(text) < 500:
        return

    save_chapter(title,url,text)

    notify(title)

def process_novel(url):

    html = fetch(url)

    soup = parse(html)

    chapters = detect_chapter_links(soup)

    for ch in chapters[:20]:
        try:
            process_chapter(ch)
        except:
            pass

def run():

    for novel in NOVEL_LIST:
        process_novel(novel)

if __name__ == "__main__":
    init_db()
    run()
