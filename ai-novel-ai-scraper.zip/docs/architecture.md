
System Pipeline

Scheduler → Crawler → Parser → AI Extraction → Cleaner → Database → Notifications

The system can adapt to multiple sites using pattern learning.
