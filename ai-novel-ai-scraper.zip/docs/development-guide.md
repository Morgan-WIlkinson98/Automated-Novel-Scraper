
1. Install dependencies
2. Add novel URLs to NOVEL_LIST in main.py
3. Run the scraper
4. Chapters will be stored in SQLite
