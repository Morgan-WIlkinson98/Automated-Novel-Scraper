
SCRAPE_INTERVAL_MINUTES = 30
DATABASE_FILE = "novels.db"

USER_AGENT = "Mozilla/5.0 NovelScraperBot"
