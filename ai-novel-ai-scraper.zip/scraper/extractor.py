
def extract_main_text(soup):

    candidates = []

    for tag in soup.find_all(["div","article","section"]):
        text = tag.get_text(" ", strip=True)

        length = len(text)

        if length > 500:
            candidates.append((length, tag))

    if not candidates:
        return ""

    best = max(candidates, key=lambda x: x[0])[1]

    return best.get_text("\n", strip=True)
