
from database.db import get_conn

def chapter_exists(url):

    conn = get_conn()

    c = conn.cursor()

    c.execute("SELECT id FROM chapters WHERE url=?",(url,))

    r = c.fetchone()

    conn.close()

    return r is not None
