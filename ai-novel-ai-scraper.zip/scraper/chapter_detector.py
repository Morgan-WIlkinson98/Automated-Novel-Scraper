
def detect_chapter_links(soup):

    links = []

    for a in soup.find_all("a"):

        href = a.get("href")

        if not href:
            continue

        h = href.lower()

        if "chapter" in h or "ch-" in h:
            links.append(href)

    return list(set(links))
