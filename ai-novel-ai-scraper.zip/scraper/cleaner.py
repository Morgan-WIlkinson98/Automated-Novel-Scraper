
def clean_text(text):

    lines = text.split("\n")

    clean = []

    for line in lines:

        line = line.strip()

        if len(line) > 40:
            clean.append(line)

    return "\n".join(clean)
