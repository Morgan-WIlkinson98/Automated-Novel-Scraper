
import sqlite3
from config.settings import DATABASE_FILE

def get_conn():
    return sqlite3.connect(DATABASE_FILE)

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute('''
    CREATE TABLE IF NOT EXISTS novels(
        id INTEGER PRIMARY KEY,
        title TEXT,
        url TEXT
    )
    ''')

    c.execute('''
    CREATE TABLE IF NOT EXISTS chapters(
        id INTEGER PRIMARY KEY,
        novel_id INTEGER,
        title TEXT,
        url TEXT,
        content TEXT
    )
    ''')

    conn.commit()
    conn.close()
